-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 27, 2018 at 05:41 PM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dillon_titcomb`
--
CREATE DATABASE IF NOT EXISTS `dillon_titcomb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `dillon_titcomb`;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `stylist_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `stylist_id`) VALUES
(1, 'Adam Smith', 4),
(2, 'Alexander Hamilton', 9),
(3, 'Bugs Bunny', 10),
(4, 'Mufasa', 2),
(5, 'Joe Jonas', 1),
(8, 'Solid Snake', 8),
(9, 'Esmeralda Cruz', 6),
(10, 'Quentin Jones', 5),
(11, 'Brian Dooley', 3),
(12, 'Oswald Grinch', 7),
(13, 'Bob Thompson', 4),
(14, 'Alexandra Pratt', 9),
(15, 'Samantha Bee', 9),
(16, 'Logan Paul', 10),
(17, 'Victor Kirilenko', 2),
(18, 'Ryan Lochte', 1),
(19, 'Conan O\'Brien', 8),
(20, 'Jimmy Fallon', 6),
(21, 'Chris Hayes', 5),
(22, 'Dana Loesche', 3),
(23, 'Post Malone', 7);

-- --------------------------------------------------------

--
-- Table structure for table `stylists`
--

CREATE TABLE `stylists` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stylists`
--

INSERT INTO `stylists` (`id`, `name`) VALUES
(1, 'John Doe'),
(2, 'Jane Doe'),
(3, 'Sam Smith'),
(4, 'Alex Johnson'),
(5, 'Sally Smart'),
(6, 'Leslie Knope'),
(7, 'Tim Allen'),
(8, 'Josh Alexander'),
(9, 'Betty Smith'),
(10, 'Elmer Fudd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stylists`
--
ALTER TABLE `stylists`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `stylists`
--
ALTER TABLE `stylists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
